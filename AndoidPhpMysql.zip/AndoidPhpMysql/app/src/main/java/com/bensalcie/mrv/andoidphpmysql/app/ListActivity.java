package com.bensalcie.mrv.andoidphpmysql.app;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ImageView;
import android.widget.ListView;

import com.amigold.fundapter.BindDictionary;
import com.amigold.fundapter.FunDapter;
import com.amigold.fundapter.extractors.StringExtractor;
import com.amigold.fundapter.interfaces.DynamicImageLoader;
import com.kosalgeek.android.json.JsonConverter;
import com.kosalgeek.genasync12.AsyncResponse;
import com.kosalgeek.genasync12.PostResponseAsyncTask;
import com.nostra13.universalimageloader.core.ImageLoader;
import com.squareup.picasso.Picasso;

import java.io.Serializable;
import java.util.ArrayList;

public class ListActivity extends AppCompatActivity implements AsyncResponse,Serializable, AdapterView.OnItemClickListener   {
    final String LOG="ListActivity";
    private ArrayList<Product> productList;
    private ListView lvProduct;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "You are sharing headlines", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
                
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(false);
        ImageLoader.getInstance().init(UILConfig.config(ListActivity.this));
        PostResponseAsyncTask taskRead=new PostResponseAsyncTask(ListActivity.this, this);
        taskRead.execute("http://www.hugetechcommunity.com/applibrary/product.php");




    }

    @Override
    public void processFinish(String s) {

                productList= new JsonConverter<Product>().toArrayList(s, Product.class);
                //Log.d(LOG, s);
        BindDictionary<Product>dict=new BindDictionary<Product>();
        dict.addStringField(R.id.etName, new StringExtractor<Product>() {
            @Override
            public String getStringValue(Product product, int position) {
                return ""+product.appname;
            }
        });

        dict.addDynamicImageField(R.id.ivImage, new StringExtractor<Product>() {
            @Override
            public String getStringValue(Product product, int position) {
                return product.location;
            }
        }, new DynamicImageLoader() {
            @Override
            public void loadImage(String url, ImageView imageView) {
                 //imageView.setImageResource();
                Picasso.with(ListActivity.this)
                       .load(url)
                       .placeholder(android.R.drawable.star_big_on)
                        .error(android.R.drawable.stat_sys_download)
                        .into(imageView);
               // ImageLoader.getInstance().displayImage(url,imageView);


            }
        });

        dict.addStringField(R.id.etPrice, new StringExtractor<Product>() {
            @Override
            public String getStringValue(Product product, int position) {
                return "News By: "+product.dev;
            }
        });
        dict.addStringField(R.id.etAppcaption, new StringExtractor<Product>() {
            @Override
            public String getStringValue(Product product, int position) {
                return "Storyline: " + product.appcaption;
            }
        });
        dict.addStringField(R.id.tvQty, new StringExtractor<Product>() {
            @Override
            public String getStringValue(Product product, int position) {
                return "Occurance: " + product.filename;
            }
        });

        dict.addStringField(R.id.tvFilename, new StringExtractor<Product>() {
            @Override
            public String getStringValue(Product product, int position) {
                return "News Category: " + product.category;
            }
        });
        FunDapter<Product> adapter=new FunDapter<>(ListActivity.this,productList,R.layout.layout_list,dict);

        lvProduct= (ListView) findViewById(R.id.lvProduct);
        lvProduct.setAdapter(adapter);
        lvProduct.setOnItemClickListener(this);

    }

    @Override
    public void onItemClick (AdapterView<?> parent, View view, int position, long id) {

        Product selectedProduct=productList.get(position);

    Intent in=new Intent(ListActivity.this,DetailActivity.class);
   // in.putExtra("product", (Serializable) selectedProduct);
        //in.putExtra("product", (Serializable) selectedProduct);
      //in.putExtra("product", (Serializable) selectedProduct);
        //in.putExtra("product", (Serializable) selectedProduct);
        in.putExtra("product", (Serializable) selectedProduct);
      startActivity(in);
    }
}
