package com.bensalcie.mrv.andoidphpmysql.app;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;

public class FullActivity extends AppCompatActivity {
    EditText title,area,name,category,description,url;
    ImageView image;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_full);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        Product product=(Product)getIntent().getSerializableExtra("product");
        title= (EditText) findViewById(R.id.etName);
        area= (EditText) findViewById(R.id.etPrice);
        name= (EditText) findViewById(R.id.etFilename);
        category= (EditText) findViewById(R.id.etQty);
        description= (EditText) findViewById(R.id.etAppcaption);
        url= (EditText) findViewById(R.id.etImageUrl);
        image= (ImageView) findViewById(R.id.ivImage);

        //if (product !=null)
       // {
           // title.setText(product.appname);
        //}
    }

}
