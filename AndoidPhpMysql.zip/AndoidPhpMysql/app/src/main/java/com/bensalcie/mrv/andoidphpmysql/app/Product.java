package com.bensalcie.mrv.andoidphpmysql.app;

import com.google.gson.annotations.SerializedName;

/**
 * Created by Mr V on 7/21/2016.
 */
public class Product {
    @SerializedName("id")
    public int id;

    @SerializedName("appname")
    public String appname;

    @SerializedName("location")
    public String location;

    @SerializedName("dev")
    public String dev;

    @SerializedName("filename")
    public String filename;



    @SerializedName("appcaption")
    public String appcaption;

    @SerializedName("category")
    public String category;
}
