package com.bensalcie.mrv.andoidphpmysql.app;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import com.nostra13.universalimageloader.core.ImageLoader;

import java.io.Serializable;

public class DetailActivity extends AppCompatActivity implements Serializable {
    EditText etName,etAppcaption,etQty,etPrice,etFilename;
    ImageView ivImage;
    Button btnUpdate;
    TextView tvImageUrl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

       /* FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });*/

        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        ImageLoader.getInstance().init(UILConfig.config(DetailActivity.this));
        //Product product=(Product)getIntent().getSerializableExtra("products");

       // Product product=(Product)getIntent().getSerializableExtra("product");
        Product product = (Product) getIntent().getSerializableExtra("product");
        etName= (EditText) findViewById(R.id.etName);
        etAppcaption= (EditText) findViewById(R.id.etAppcaption);
        etQty= (EditText) findViewById(R.id.etQty);
        etPrice= (EditText) findViewById(R.id.etPrice);
        ivImage=(ImageView)findViewById(R.id.ivImage);
        btnUpdate=(Button)findViewById(R.id.btnUpdate);
        tvImageUrl= (TextView) findViewById(R.id.tvImageUrl);
        //etName.setText(""+product.appname);
        if (product!=null){
            etName.setText(""+product.appname);
            etAppcaption.setText(""+product.appcaption);
            etQty.setText(""+product.filename);
            etPrice.setText(""+product.dev);
            etFilename.setText(""+product.category);
            tvImageUrl.setText(""+product.location);

            //ImageLoader.getInstance().displayImage(product.location, ivImage);

        }
    }

}
